import { useState, useEffect } from 'react';
import { motion, useScroll, useSpring } from 'framer-motion';
import { Github, Linkedin, Mail, ChevronDown, Terminal, ExternalLink, Code2, Layout, Globe, GitBranch, Smartphone, Monitor, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Home() {
  const [activeSection, setActiveSection] = useState('home');
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'skills', 'projects', 'contact'];
      const scrollPosition = window.scrollY + 100;
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) window.scrollTo({ top: element.offsetTop, behavior: 'smooth' });
  };

  const navItems = ['Home', 'About', 'Skills', 'Projects', 'Contact'];

  const skills = [
    { name: 'HTML5 & Semantics', icon: Code2 },
    { name: 'CSS3 · Flexbox · Grid', icon: Layout },
    { name: 'JavaScript (ES6+)', icon: Terminal },
    { name: 'jQuery', icon: Code2 },
    { name: 'Bootstrap 5', icon: Palette },
    { name: 'Responsive Design', icon: Monitor },
    { name: 'Git & GitHub', icon: GitBranch },
    { name: 'Flutter & Dart', icon: Smartphone },
  ];

  const featuredProjects = [
    {
      title: 'TaskFlow',
      label: 'Featured Project',
      description: 'A full-stack project management app with a React + Vite frontend and an Express 5 REST API backed by PostgreSQL. Features a live dashboard with completion stats, project boards with colour-coded progress bars, task CRUD with status cycling, and an all-tasks view with filters — all generated from a typed OpenAPI contract.',
      tech: ['React', 'Express 5', 'PostgreSQL', 'Drizzle ORM', 'TypeScript', 'OpenAPI'],
      github: 'https://github.com/MAayanBhatti',
      live: '/',
      icon: Terminal,
      align: 'right' as const,
    },
    {
      title: 'Chess Game',
      label: 'Featured Project',
      description: 'Mobile-responsive chess game with full check and checkmate detection, pawn promotion mechanics, and dual player timers. Built entirely with vanilla JavaScript — no libraries, just pure logic.',
      tech: ['Vanilla JavaScript', 'HTML5', 'CSS3', 'Game Logic'],
      github: 'https://github.com/MAayanBhatti',
      live: '#',
      icon: Globe,
      align: 'left' as const,
    },
    {
      title: 'Expense Tracker',
      label: 'Featured Project',
      description: 'A clean, interactive web app to log and categorize personal expenses with real-time balance calculation and local data persistence. Designed for everyday usability with a minimal, distraction-free interface.',
      tech: ['JavaScript', 'HTML5', 'CSS3', 'localStorage'],
      github: 'https://github.com/MAayanBhatti',
      live: '#',
      icon: Layout,
      align: 'right' as const,
    },
  ];

  const otherProjects = [
    {
      title: 'To-Do Web App',
      description: 'Task management application with add, complete, and delete functionality — built for speed and usability with a minimal interface.',
      tech: ['JavaScript', 'HTML5', 'CSS3'],
      github: 'https://github.com/MAayanBhatti',
      live: '#',
    },
    {
      title: 'Dark-Mode Calculator',
      description: 'Fully styled calculator with custom dark theme, keyboard shortcut support, and clean operator logic using JavaScript.',
      tech: ['JavaScript', 'CSS3', 'HTML5'],
      github: 'https://github.com/MAayanBhatti',
      live: '#',
    },
    {
      title: 'jQuery & Bootstrap Forms',
      description: 'Real-world UI forms with validation, dynamic interactions, and responsive Bootstrap grid layouts for practical usability.',
      tech: ['jQuery', 'Bootstrap 5', 'HTML5'],
      github: 'https://github.com/MAayanBhatti',
      live: '#',
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/30">
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-primary z-50 origin-left"
        style={{ scaleX }}
      />

      {/* Navigation */}
      <nav className="fixed top-0 w-full z-40 bg-background/80 backdrop-blur-md border-b border-white/5">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <div className="font-mono font-bold text-xl tracking-tighter text-primary">
            MAB<span className="text-foreground">.dev</span>
          </div>
          <div className="hidden md:flex gap-8">
            {navItems.map((item) => (
              <button
                key={item}
                onClick={() => scrollTo(item.toLowerCase())}
                className={`text-sm font-medium tracking-wide uppercase transition-colors hover:text-primary ${
                  activeSection === item.toLowerCase() ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center pt-16 overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-20">
          <img
            src={`${import.meta.env.BASE_URL}hero-abstract.png`}
            alt="Abstract code background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background to-background" />
        </div>

        <div className="container px-6 relative z-10">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex items-center gap-3 mb-6"
            >
              <div className="h-[1px] w-12 bg-primary" />
              <span className="font-mono text-primary uppercase tracking-widest text-sm">Hello World</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-6xl md:text-8xl font-bold tracking-tighter leading-[1.1] mb-6"
            >
              I'm Muhammad<br />
              <span className="text-muted-foreground">Aayan Bhatti.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-2xl leading-relaxed"
            >
              Front-End Developer & IT Intern Applicant at{' '}
              <span className="text-foreground font-semibold">Gexton</span>.{' '}
              Building responsive, interactive web experiences with clean code and sharp UI.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-wrap gap-4"
            >
              <Button size="lg" onClick={() => scrollTo('projects')} className="bg-primary text-primary-foreground hover:bg-primary/90 font-mono">
                View My Work
              </Button>
              <Button size="lg" variant="outline" onClick={() => scrollTo('contact')} className="font-mono border-white/10 hover:bg-white/5">
                Contact Me
              </Button>
            </motion.div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce"
        >
          <ChevronDown className="w-6 h-6 text-muted-foreground" />
        </motion.div>
      </section>

      {/* About Section */}
      <section id="about" className="py-32 bg-background relative">
        <div className="container px-6 mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-4 mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight">01. About Me</h2>
            <div className="h-[1px] flex-1 bg-white/10 max-w-md" />
          </motion.div>

          <div className="grid md:grid-cols-2 gap-16 max-w-5xl">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="space-y-6 text-lg text-muted-foreground leading-relaxed"
            >
              <p>
                Hi, I'm Aayan — a results-driven front-end developer with 2+ years of hands-on experience building responsive and interactive web applications. I'm passionate about clean UI, performant code, and turning ideas into polished, user-friendly products.
              </p>
              <p>
                I'm currently pursuing a <span className="text-foreground font-medium">Higher Diploma in Software Engineering (HDSE)</span> at Aptech Pakistan, on the Full-Stack Developer track. I also hold certifications from the University of Michigan, IBM, and Google Cloud.
              </p>
              <p className="text-foreground border-l-2 border-primary pl-4 font-medium italic">
                I'm actively seeking an IT internship to contribute, learn, and grow within a professional team — and Gexton is exactly the kind of environment I want to be part of.
              </p>
              <div className="flex items-center gap-2 text-sm font-mono text-muted-foreground pt-2">
                <span className="text-primary">📍</span> Jamshoro, Pakistan
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="relative group"
            >
              <div className="absolute -inset-4 bg-gradient-to-r from-primary to-blue-600 opacity-20 blur-2xl group-hover:opacity-30 transition-opacity duration-500 rounded-xl" />
              <div className="relative h-full min-h-[300px] border border-white/10 rounded-xl bg-card p-8 flex flex-col justify-center gap-6">
                <Terminal className="w-10 h-10 text-primary" />
                <div>
                  <h3 className="text-xl font-bold mb-3">Why Gexton?</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    I want to work in a place where I write real code for real users — not just coursework. Gexton's reputation for building robust software products makes it the right first step. I bring 2+ years of self-directed practice, a sharp eye for UI, and the hunger to level up fast alongside experienced engineers.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-2">
                  {['HTML & CSS', 'JavaScript', 'Bootstrap', 'jQuery', 'Git', 'Responsive'].map(t => (
                    <span key={t} className="font-mono text-xs text-primary bg-primary/10 border border-primary/20 rounded px-2 py-1 text-center">{t}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-32 bg-zinc-950/50 relative border-y border-white/5">
        <div className="container px-6 mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-4 mb-16 justify-end"
          >
            <div className="h-[1px] flex-1 bg-white/10 max-w-md" />
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight">02. Skills</h2>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto">
            {skills.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.07 }}
                className="flex items-center gap-3 p-4 border border-white/5 rounded-lg bg-background hover:border-primary/50 transition-all duration-200 group hover:bg-primary/5"
              >
                <skill.icon className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                <span className="font-mono text-sm leading-tight">{skill.name}</span>
              </motion.div>
            ))}
          </div>

          {/* Certifications */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="max-w-5xl mx-auto mt-16"
          >
            <p className="font-mono text-primary text-sm uppercase tracking-widest mb-8">Certifications</p>
            <div className="space-y-8">
              {[
                {
                  category: 'Flutter & Dart',
                  color: 'from-cyan-500/10 to-blue-500/10 border-cyan-500/20',
                  certs: [
                    { name: 'Getting Started with Flutter Development', org: 'Google Cloud' },
                    { name: 'Flutter Quick Start', org: 'Google Cloud' },
                    { name: 'Flutter Startup Namer', org: 'Google Cloud' },
                    { name: 'Material Components for Flutter Basics', org: 'Google Cloud' },
                    { name: 'Working with Onscreen Data in a Flutter Application', org: 'Google Cloud' },
                    { name: 'Introduction to Dart', org: 'Google Cloud' },
                    { name: 'Dart Functions Framework', org: 'Google Cloud' },
                  ],
                },
                {
                  category: 'Web Development',
                  color: 'from-primary/10 to-indigo-500/10 border-primary/20',
                  certs: [
                    { name: 'HTML & CSS: Building a Single-Page Website', org: 'University of Michigan / Coursera' },
                    { name: 'HTML Introduction', org: 'Coursera' },
                    { name: 'Design Restaurant Menu Website using HTML & CSS', org: 'Coursera Project Network' },
                    { name: 'Build Your Portfolio', org: 'Coursera' },
                  ],
                },
                {
                  category: 'Data, Business & Tools',
                  color: 'from-violet-500/10 to-pink-500/10 border-violet-500/20',
                  certs: [
                    { name: 'Python for Everybody', org: 'University of Michigan / Coursera' },
                    { name: 'Data Science Fundamentals', org: 'IBM' },
                    { name: 'Small Business Marketing Using YouTube', org: 'Google / Coursera' },
                    { name: 'Microsoft Word', org: 'Coursera' },
                  ],
                },
              ].map((group, gi) => (
                <div key={group.category}>
                  <p className={`text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3`}>{group.category}</p>
                  <div className={`grid md:grid-cols-2 gap-2 p-4 rounded-xl bg-gradient-to-br border ${group.color}`}>
                    {group.certs.map((cert, i) => (
                      <motion.div
                        key={cert.name}
                        initial={{ opacity: 0, x: -10 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.3, delay: gi * 0.1 + i * 0.04 }}
                        className="flex items-start gap-3 p-3 rounded-lg bg-background/40"
                      >
                        <span className="text-primary font-mono text-xs mt-0.5 flex-shrink-0">▸</span>
                        <div>
                          <p className="text-sm font-medium leading-tight">{cert.name}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">{cert.org}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-32 bg-background relative">
        <div className="container px-6 mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-4 mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight">03. Things I've Built</h2>
            <div className="h-[1px] flex-1 bg-white/10 max-w-md" />
          </motion.div>

          {/* Featured Projects */}
          <div className="space-y-32 max-w-6xl mx-auto mb-24">
            {featuredProjects.map((project, idx) => {
              const isRight = project.align === 'right';
              return (
                <motion.div
                  key={project.title}
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-100px' }}
                  transition={{ duration: 0.7 }}
                  className="relative grid md:grid-cols-12 gap-8 items-center"
                >
                  {/* Project preview mockup */}
                  <div className={`md:col-span-7 relative z-10 md:row-start-1 ${isRight ? 'md:col-start-1' : 'md:col-start-6'}`}>
                    <div className="aspect-video rounded-xl border border-white/10 overflow-hidden bg-zinc-900 group hover:border-primary/40 transition-colors duration-300">
                      {idx === 0 && (
                        /* TaskFlow dashboard mockup */
                        <div className="w-full h-full flex text-[10px] font-mono">
                          <div className="w-14 bg-[#0e1628] flex flex-col items-center py-3 gap-3 border-r border-white/5">
                            <div className="w-6 h-6 rounded bg-primary/80 mb-2" />
                            {['▪','▪','▪','▪'].map((d,i) => <div key={i} className={`w-5 h-5 rounded ${i===0?'bg-primary/20 border border-primary/40':'bg-white/5'}`} />)}
                          </div>
                          <div className="flex-1 p-4 flex flex-col gap-3">
                            <div className="flex gap-3">
                              {[['12','Projects','text-primary'],['38','Tasks','text-blue-400'],['62%','Done','text-emerald-400']].map(([v,l,c])=>(
                                <div key={l} className="flex-1 bg-white/5 rounded-lg p-2 border border-white/5">
                                  <div className={`text-lg font-bold ${c}`}>{v}</div>
                                  <div className="text-white/40">{l}</div>
                                </div>
                              ))}
                            </div>
                            <div className="flex-1 bg-white/5 rounded-lg p-2 border border-white/5">
                              <div className="text-white/40 mb-2">Recent Tasks</div>
                              {[['Design homepage','Done','bg-emerald-500'],['Fix login bug','In Progress','bg-blue-500'],['Write API docs','Todo','bg-white/30']].map(([t,s,c])=>(
                                <div key={t} className="flex items-center gap-2 py-1 border-b border-white/5 last:border-0">
                                  <div className={`w-1.5 h-1.5 rounded-full ${c}`} />
                                  <span className="text-white/70 flex-1">{t}</span>
                                  <span className="text-white/30">{s}</span>
                                </div>
                              ))}
                            </div>
                            <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                              <div className="h-full w-[62%] bg-primary rounded-full" />
                            </div>
                          </div>
                        </div>
                      )}
                      {idx === 1 && (
                        /* Chess game mockup */
                        <div className="w-full h-full flex items-center justify-center bg-zinc-950 p-6">
                          <div className="flex flex-col gap-0.5">
                            {Array.from({length:6}).map((_,r)=>(
                              <div key={r} className="flex gap-0.5">
                                {Array.from({length:6}).map((_,c)=>{
                                  const light = (r+c)%2===0;
                                  const isPiece = (r===0&&c===0)||(r===0&&c===4)||(r===1&&c===1)||(r===1&&c===3)||(r===4&&c===2)||(r===5&&c===1)||(r===5&&c===5);
                                  const isWhite = r<3;
                                  return (
                                    <div key={c} className={`w-10 h-10 rounded-sm flex items-center justify-center text-lg ${light?'bg-amber-100/20':'bg-amber-900/40'}`}>
                                      {isPiece && <span className={isWhite?'text-white drop-shadow':'text-zinc-800'}>{['♟','♞','♜','♛'][((r+c)%4)]}</span>}
                                    </div>
                                  );
                                })}
                              </div>
                            ))}
                          </div>
                          <div className="ml-4 flex flex-col gap-3 text-xs font-mono">
                            <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                              <div className="text-white/40 text-[10px] mb-1">Player 1</div>
                              <div className="text-primary text-xl font-bold">05:42</div>
                            </div>
                            <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                              <div className="text-white/40 text-[10px] mb-1">Player 2</div>
                              <div className="text-white text-xl font-bold">08:11</div>
                            </div>
                          </div>
                        </div>
                      )}
                      {idx === 2 && (
                        /* Expense tracker mockup */
                        <div className="w-full h-full flex flex-col bg-zinc-950 p-5 font-mono text-[10px]">
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <div className="text-white/40 mb-0.5">Total Balance</div>
                              <div className="text-2xl font-bold text-emerald-400">$2,480.50</div>
                            </div>
                            <div className="bg-primary/20 border border-primary/30 text-primary px-3 py-1 rounded-full">+ Add</div>
                          </div>
                          <div className="flex gap-2 mb-4">
                            {[['Food','$340','bg-orange-500/70'],['Transport','$120','bg-blue-500/70'],['Shopping','$580','bg-violet-500/70']].map(([cat,amt,c])=>(
                              <div key={cat} className="flex-1 bg-white/5 rounded-lg p-2 border border-white/5">
                                <div className={`w-full h-1 rounded-full ${c} mb-2`} />
                                <div className="text-white/40">{cat}</div>
                                <div className="text-white font-bold">{amt}</div>
                              </div>
                            ))}
                          </div>
                          <div className="flex-1 space-y-1.5">
                            {[['Grocery run','Food','-$45.00','text-red-400'],['Salary','Income','+$1,200','text-emerald-400'],['Uber','Transport','-$12.50','text-red-400']].map(([n,c,a,col])=>(
                              <div key={n} className="flex items-center gap-2 bg-white/5 rounded-lg px-3 py-2 border border-white/5">
                                <div className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-base">💳</div>
                                <div className="flex-1">
                                  <div className="text-white/80">{n}</div>
                                  <div className="text-white/30">{c}</div>
                                </div>
                                <div className={`font-bold ${col}`}>{a}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Text */}
                  <div className={`md:col-span-6 relative z-20 ${isRight ? 'md:col-start-7 md:text-right' : 'md:col-start-1 md:text-left'}`}>
                    <p className="font-mono text-primary text-sm mb-2">{project.label}</p>
                    <h3 className="text-2xl md:text-3xl font-bold mb-6">{project.title}</h3>
                    <div className="bg-card p-6 md:p-8 rounded-xl border border-white/5 text-muted-foreground shadow-2xl mb-6">
                      <p>{project.description}</p>
                    </div>
                    <ul className={`flex flex-wrap gap-4 font-mono text-sm text-muted-foreground mb-6 ${isRight ? 'md:justify-end' : 'md:justify-start'}`}>
                      {project.tech.map(t => <li key={t}>{t}</li>)}
                    </ul>
                    <div className={`flex items-center gap-4 ${isRight ? 'md:justify-end' : 'md:justify-start'}`}>
                      <a href={project.github} target="_blank" rel="noreferrer" className="text-foreground hover:text-primary transition-colors">
                        <Github className="w-6 h-6" />
                      </a>
                      <a href={project.live} target="_blank" rel="noreferrer" className="text-foreground hover:text-primary transition-colors">
                        <ExternalLink className="w-6 h-6" />
                      </a>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Other Projects */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-5xl mx-auto"
          >
            <p className="font-mono text-primary text-sm uppercase tracking-widest text-center mb-10">Other Noteworthy Projects</p>
            <div className="grid md:grid-cols-2 gap-6">
              {otherProjects.map((project, i) => (
                <motion.div
                  key={project.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.1 }}
                  className="flex flex-col gap-4 p-6 border border-white/5 rounded-xl bg-card hover:border-primary/30 transition-colors group"
                >
                  <div className="flex items-center justify-between">
                    <Code2 className="w-8 h-8 text-primary/60 group-hover:text-primary transition-colors" />
                    <div className="flex items-center gap-3">
                      <a href={project.github} target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                        <Github className="w-5 h-5" />
                      </a>
                      <a href={project.live} target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                        <ExternalLink className="w-5 h-5" />
                      </a>
                    </div>
                  </div>
                  <h3 className="text-lg font-bold">{project.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed flex-1">{project.description}</p>
                  <div className="flex flex-wrap gap-2 pt-2">
                    {project.tech.map(t => (
                      <span key={t} className="font-mono text-xs text-muted-foreground">{t}</span>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 bg-zinc-950/50 border-t border-white/5 text-center">
        <div className="container px-6 mx-auto max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <p className="font-mono text-primary mb-4 tracking-widest text-sm">04. What's Next?</p>
            <h2 className="text-4xl md:text-6xl font-bold tracking-tight mb-6">Get In Touch</h2>
            <p className="text-lg text-muted-foreground mb-10 leading-relaxed">
              I'm actively looking for an IT internship and would love to connect. Whether you have an opportunity at Gexton or just want to say hi — my inbox is open.
            </p>

            <a href="mailto:maayanbhatti10@gmail.com">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-mono text-base px-8 h-14">
                maayanbhatti10@gmail.com
              </Button>
            </a>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-background text-center text-muted-foreground font-mono text-sm flex flex-col items-center gap-4">
        <div className="flex gap-6">
          <a href="https://github.com/MAayanBhatti" target="_blank" rel="noreferrer" className="hover:text-primary transition-colors">
            <Github className="w-5 h-5" />
          </a>
          <a href="https://linkedin.com/in/muhammadaayan-110ab227b" target="_blank" rel="noreferrer" className="hover:text-primary transition-colors">
            <Linkedin className="w-5 h-5" />
          </a>
          <a href="mailto:maayanbhatti10@gmail.com" className="hover:text-primary transition-colors">
            <Mail className="w-5 h-5" />
          </a>
        </div>
        <p>Muhammad Aayan Bhatti · Front-End Developer · Jamshoro, Pakistan</p>
      </footer>
    </div>
  );
}
